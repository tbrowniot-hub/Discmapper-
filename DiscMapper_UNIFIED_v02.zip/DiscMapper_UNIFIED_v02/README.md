# DiscMapper UNIFIED v0.2 (Movies + TV)

## Install
1. Extract the folder to:
   - `C:\DiscMapper_UNIFIED_v02\`

2. Double-click:
   - `DiscMapper_Unified_Launcher.ps1`

> If PowerShell blocks scripts: run PowerShell as your user and do:
> `Set-ExecutionPolicy -Scope Process Bypass`

## Inputs (drop your refresh files here)
Put your current CSVs here anytime you want to refresh:
- Movies (CLZ export): `C:\DiscMapper_UNIFIED_v02\Inputs\CLZ_export.csv`
- TV manifest: `C:\DiscMapper_UNIFIED_v02\Inputs\tv_manifest.csv`

## Data files this tool generates
- Indexes:
  - `Data\Indexes\clz_index.json`
  - `Data\Indexes\tv_index.json`
- Queues:
  - Movies queue: `Data\Queues\queue.json`
  - TV queue: `Data\Queues\tv_queue.json`

## Output (fresh staging paths)
All ripping/moving happens under:
- `C:\DiscMapper_UNIFIED_v02\Staging\`

Movies:
- Raw: `Staging\Movies\1_Raw`
- Review: `Staging\Movies\2_Review`
- Ready: `Staging\Movies\3_Ready`

TV:
- Raw: `Staging\TV\1_Raw`
- Review: `Staging\TV\2_Review`
- Ready: `Staging\TV\3_Ready`

Shared:
- Unable to read: `Staging\Unable_to_Read`

## Requirements
- Python 3.x installed (and `python` available in PATH)
- MakeMKV installed
- FFmpeg installed (so `ffprobe` is available in PATH)

## Typical flow
1) Launcher → **Refresh Index** (Movies or TV)  
2) Launcher → **Build Queue** (Movies or TV)  
3) Launcher → **Run Rip Queue** (Movies or TV)
