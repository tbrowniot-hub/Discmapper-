#!/usr/bin/env python3
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

# Local modules shipped in the same folder
import discmapper_v02 as movies
import discmapper_tv_v02 as tv


def app_dir() -> Path:
    return Path(__file__).resolve().parent


def root_dir() -> Path:
    # ...\DiscMapper_UNIFIED_v02
    return app_dir().parent


def require_file(p: Path, label: str) -> None:
    if not p.exists():
        raise FileNotFoundError(f"{label} not found: {p}")


def choose_mode_gui() -> str:
    """Small modal to pick Movies vs TV. Returns 'movies' or 'tv'."""
    import tkinter as tk
    from tkinter import ttk

    choice = {"mode": None}

    root = tk.Tk()
    root.title("DiscMapper UNIFIED v0.2 — Select Type")
    root.geometry("440x190")
    root.resizable(False, False)

    frm = ttk.Frame(root, padding=16)
    frm.pack(fill="both", expand=True)

    ttk.Label(
        frm,
        text="What do you want to work on?",
        font=("Segoe UI", 11),
    ).pack(anchor="w", pady=(0, 12))

    btns = ttk.Frame(frm)
    btns.pack(fill="x", pady=(0, 12))

    def pick(m: str) -> None:
        choice["mode"] = m
        root.destroy()

    ttk.Button(btns, text="Movies (CLZ)", command=lambda: pick("movies")).pack(
        side="left", expand=True, fill="x", padx=(0, 8)
    )
    ttk.Button(btns, text="TV (Manifest)", command=lambda: pick("tv")).pack(
        side="left", expand=True, fill="x"
    )

    ttk.Label(
        frm,
        text="Tip: Use the launcher option 'Refresh Index' when you add new items.",
        font=("Segoe UI", 9),
    ).pack(anchor="w")

    root.mainloop()

    if choice["mode"] not in ("movies", "tv"):
        raise SystemExit(0)
    return choice["mode"]


def default_paths() -> dict:
    r = root_dir()
    return {
        "clz_csv": r / "Inputs" / "CLZ_export.csv",
        "tv_manifest": r / "Inputs" / "tv_manifest.csv",
        "movies_index": r / "Data" / "Indexes" / "clz_index.json",
        "tv_index": r / "Data" / "Indexes" / "tv_index.json",
        "movies_queue": r / "Data" / "Queues" / "queue.json",
        "tv_queue": r / "Data" / "Queues" / "tv_queue.json",
        "tv_config": app_dir() / "config_tv.json",
    }


def cmd_refresh_index(args: argparse.Namespace) -> None:
    mode = args.mode or choose_mode_gui()

    if mode == "movies":
        require_file(Path(args.clz_csv), "CLZ CSV")
        movies.cmd_import_clz(SimpleNamespace(clz=str(args.clz_csv), out=str(args.movies_index)))
        return

    if mode == "tv":
        require_file(Path(args.tv_manifest), "TV manifest CSV")
        tv.cmd_import_manifest(SimpleNamespace(manifest=str(args.tv_manifest), out=str(args.tv_index)))
        return

    raise ValueError(f"Unknown mode: {mode}")


def cmd_queue_builder(args: argparse.Namespace) -> None:
    mode = args.mode or choose_mode_gui()

    if mode == "movies":
        require_file(Path(args.movies_index), "clz_index.json")
        movies.cmd_queue(SimpleNamespace(index=str(args.movies_index), out=str(args.movies_queue)))
        return

    if mode == "tv":
        require_file(Path(args.tv_index), "tv_index.json")
        tv.cmd_queue_builder(SimpleNamespace(index=str(args.tv_index), out=str(args.tv_queue)))
        return

    raise ValueError(f"Unknown mode: {mode}")


def cmd_run_rip(args: argparse.Namespace) -> None:
    """Prompt Movies vs TV, then run the appropriate rip engine."""
    mode = args.mode or choose_mode_gui()
    py = sys.executable
    cwd = str(app_dir())

    if mode == "movies":
        require_file(Path(args.movies_queue), "queue.json (movies)")
        cmd = [py, str(app_dir() / "discmapper_v02.py"), "rip", "--queue", str(args.movies_queue)]
        raise SystemExit(subprocess.call(cmd, cwd=cwd))

    if mode == "tv":
        require_file(Path(args.tv_index), "tv_index.json")
        require_file(Path(args.tv_queue), "tv_queue.json")
        cmd = [
            py,
            str(app_dir() / "discmapper_tv_v02.py"),
            "rip-queue",
            "--index",
            str(args.tv_index),
            "--queue",
            str(args.tv_queue),
            "--config",
            str(args.tv_config),
        ]
        raise SystemExit(subprocess.call(cmd, cwd=cwd))

    raise ValueError(f"Unknown mode: {mode}")


def main() -> None:
    p = default_paths()

    ap = argparse.ArgumentParser(prog="discmapper_unified")
    sub = ap.add_subparsers(dest="cmd", required=True)

    ri = sub.add_parser("refresh-index", help="Build/refresh CLZ index (movies) or manifest index (tv).")
    ri.add_argument("--mode", choices=["movies", "tv"], default=None)
    ri.add_argument("--clz-csv", default=str(p["clz_csv"]))
    ri.add_argument("--tv-manifest", default=str(p["tv_manifest"]))
    ri.add_argument("--movies-index", default=str(p["movies_index"]))
    ri.add_argument("--tv-index", default=str(p["tv_index"]))
    ri.set_defaults(func=cmd_refresh_index)

    qb = sub.add_parser("queue-builder", help="Open unified GUI: pick Movies or TV, then build a queue.")
    qb.add_argument("--mode", choices=["movies", "tv"], default=None)
    qb.add_argument("--movies-index", default=str(p["movies_index"]))
    qb.add_argument("--movies-queue", default=str(p["movies_queue"]))
    qb.add_argument("--tv-index", default=str(p["tv_index"]))
    qb.add_argument("--tv-queue", default=str(p["tv_queue"]))
    qb.set_defaults(func=cmd_queue_builder)

    rr = sub.add_parser("run-rip", help="Prompt Movies/TV then run the matching rip queue.")
    rr.add_argument("--mode", choices=["movies", "tv"], default=None)
    rr.add_argument("--movies-queue", default=str(p["movies_queue"]))
    rr.add_argument("--tv-index", default=str(p["tv_index"]))
    rr.add_argument("--tv-queue", default=str(p["tv_queue"]))
    rr.add_argument("--tv-config", default=str(p["tv_config"]))
    rr.set_defaults(func=cmd_run_rip)

    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
