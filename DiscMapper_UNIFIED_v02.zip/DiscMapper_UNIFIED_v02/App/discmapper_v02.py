#!/usr/bin/env python3
from __future__ import annotations

import argparse, csv, json, re, shutil, subprocess, time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

IMDB_RE = re.compile(r"(tt\d{5,10})", re.IGNORECASE)
ILLEGAL_WIN_CHARS = r'<>:"/\\|?*'

def now_ts() -> str:
    return datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

def ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)

def sanitize_name(name: str) -> str:
    cleaned = "".join("_" if c in ILLEGAL_WIN_CHARS else c for c in name)
    cleaned = re.sub(r"\s+", " ", cleaned).strip().strip(".")
    return cleaned

def atomic_write_json(path: Path, data: Dict) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    tmp.replace(path)

def read_json_any(path: Path) -> Dict:
    # BOM-safe forever
    return json.loads(path.read_text(encoding="utf-8-sig"))

def load_config(config_path: Optional[str]) -> Dict:
    if config_path:
        p = Path(config_path)
        if not p.exists(): raise FileNotFoundError(f"Config not found: {p}")
        return read_json_any(p)
    p = Path(__file__).with_name("config.json")
    if not p.exists(): raise FileNotFoundError("config.json not found next to discmapper_v02.py")
    return read_json_any(p)

@dataclass
class MovieRow:
    title: str
    year: Optional[int]
    imdb_id: str
    format: str

def extract_imdb_id(url: str) -> Optional[str]:
    if not url: return None
    m = IMDB_RE.search(url)
    return m.group(1).lower() if m else None

def read_clz_csv(csv_path: Path) -> List[MovieRow]:
    raw = csv_path.read_bytes()
    text = raw.decode("utf-8-sig", errors="replace")
    rdr = csv.DictReader(text.splitlines())
    movies: List[MovieRow] = []
    for row in rdr:
        is_tv = (row.get("Is TV Series") or "").strip().lower()
        if is_tv in ("yes","true","1"): 
            continue
        title = (row.get("Title") or "").strip()
        if not title:
            continue
        year_str = (row.get("Release Year") or "").strip()
        year = int(year_str) if year_str.isdigit() else None
        imdb_url = (row.get("IMDb Url") or "").strip()
        imdb_id = extract_imdb_id(imdb_url)
        if not imdb_id:
            # movies-only automation requires IMDb id to force Plex matching
            continue
        fmt = (row.get("Format") or "").strip()
        movies.append(MovieRow(title=title, year=year, imdb_id=imdb_id, format=fmt))
    return movies

def cmd_import_clz(args):
    clz = Path(args.clz)
    if not clz.exists(): raise FileNotFoundError(f"CLZ export not found: {clz}")
    movies = read_clz_csv(clz)
    out = Path(args.out)
    ensure_dir(out.parent)
    atomic_write_json(out, {"created_at": now_ts(), "source": str(clz), "movies": [m.__dict__ for m in movies]})
    print(f"[DiscMapper v0.2] Wrote index: {out} ({len(movies)} movies)")

def cmd_queue(args):
    import tkinter as tk
    from tkinter import ttk, messagebox

    idx_path = Path(args.index)
    if not idx_path.exists(): raise FileNotFoundError(f"Index not found: {idx_path}")
    idx = read_json_any(idx_path)
    movies = idx.get("movies", [])

    root = tk.Tk()
    root.title("DiscMapper v0.2 — Build Rip Queue (Movies)")
    root.geometry("1100x650")

    frm = ttk.Frame(root, padding=10); frm.pack(fill="both", expand=True)
    left = ttk.Frame(frm); left.pack(side="left", fill="both", expand=True, padx=(0,10))
    right = ttk.Frame(frm); right.pack(side="right", fill="both", expand=True)

    ttk.Label(left, text="Search CLZ movies").pack(anchor="w")
    search_var = tk.StringVar()
    ttk.Entry(left, textvariable=search_var).pack(fill="x", pady=(0,6))

    cols = ("title","year","format","imdb")
    tree = ttk.Treeview(left, columns=cols, show="headings", height=20)
    for c,t,w in [("title","Title",420),("year","Year",70),("format","Format",100),("imdb","IMDb",110)]:
        tree.heading(c, text=t); tree.column(c, width=w)
    tree.pack(fill="both", expand=True)

    ttk.Label(right, text="Rip queue (top → bottom)").pack(anchor="w")
    qcols = ("qtitle","qyear","qformat","qimdb")
    qtree = ttk.Treeview(right, columns=qcols, show="headings", height=20)
    for c,t,w in [("qtitle","Title",420),("qyear","Year",70),("qformat","Format",100),("qimdb","IMDb",110)]:
        qtree.heading(c, text=t); qtree.column(c, width=w)
    qtree.pack(fill="both", expand=True)

    def populate(ft=""):
        tree.delete(*tree.get_children())
        s = ft.strip().lower()
        for m in movies:
            title=m.get("title",""); year=m.get("year",""); fmt=m.get("format",""); imdb=m.get("imdb_id","")
            hay=f"{title} {year} {fmt} {imdb}".lower()
            if s and s not in hay: continue
            tree.insert("", "end", values=(title, year, fmt, imdb))

    def on_search(*_): populate(search_var.get())
    search_var.trace_add("write", on_search)
    populate("")

    def selected(t):
        sel = t.selection()
        return t.item(sel[0], "values") if sel else None

    btnrow = ttk.Frame(right); btnrow.pack(fill="x", pady=8)
    def add():
        v = selected(tree)
        if v: qtree.insert("", "end", values=v)
    def remove():
        for s in qtree.selection(): qtree.delete(s)
    def up():
        sel = qtree.selection()
        if not sel: return
        item = sel[0]; prev = qtree.prev(item)
        if prev: qtree.move(item, "", qtree.index(prev))
    def down():
        sel = qtree.selection()
        if not sel: return
        item = sel[0]; nxt = qtree.next(item)
        if nxt: qtree.move(item, "", qtree.index(nxt) + 1)

    def save():
        items=[]
        for iid in qtree.get_children():
            title, year, fmt, imdb = qtree.item(iid, "values")
            items.append({"title": title, "year": int(year) if str(year).isdigit() else None, "format": fmt, "imdb_id": str(imdb).lower()})
        if not items:
            messagebox.showwarning("DiscMapper v0.2", "Queue is empty.")
            return
        out_path = Path(args.out)
        out_path.write_text(json.dumps({"created_at": now_ts(), "index": str(idx_path), "items": items}, indent=2), encoding="utf-8")
        messagebox.showinfo("DiscMapper v0.2", f"Saved queue: {out_path}")

    ttk.Button(btnrow, text="Add →", command=add).pack(side="left", padx=(0,6))
    ttk.Button(btnrow, text="Remove", command=remove).pack(side="left", padx=(0,6))
    ttk.Button(btnrow, text="Up", command=up).pack(side="left", padx=(0,6))
    ttk.Button(btnrow, text="Down", command=down).pack(side="left", padx=(0,6))
    ttk.Button(btnrow, text="Save Queue", command=save).pack(side="right")
    root.mainloop()

def find_makemkvcon(cfg_path: str) -> Optional[str]:
    if cfg_path and Path(cfg_path).exists(): return cfg_path
    candidates = [
        r"C:\Program Files (x86)\MakeMKV\makemkvcon64.exe",
        r"C:\Program Files\MakeMKV\makemkvcon64.exe",
        r"C:\Program Files (x86)\MakeMKV\makemkvcon.exe",
        r"C:\Program Files\MakeMKV\makemkvcon.exe",
    ]
    for c in candidates:
        if Path(c).exists(): return c
    for exe in ("makemkvcon64.exe","makemkvcon.exe"):
        p = shutil.which(exe)
        if p: return p
    return None

def detect_drive_index(makemkvcon: str) -> str:
    try:
        out = subprocess.check_output([makemkvcon, "-r", "info", "disc:9999"], stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", timeout=30)
    except Exception:
        return "0"
    for line in out.splitlines():
        if line.startswith("DRV:"):
            m = re.match(r"DRV:(\d+),", line)
            return m.group(1) if m else "0"
    return "0"

def get_optical_drive_letter() -> Optional[str]:
    ps = "(Get-CimInstance Win32_CDROMDrive | Select-Object -First 1 -ExpandProperty Drive)"
    try:
        out = subprocess.check_output(["powershell","-NoProfile","-Command",ps], stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", timeout=10).strip()
        out = out.strip()
        if out and re.match(r"^[A-Z]:$", out.upper()): return out.upper()
    except Exception:
        return None
    return None

def is_media_loaded() -> bool:
    ps = "(Get-CimInstance Win32_CDROMDrive | Select-Object -First 1 -ExpandProperty MediaLoaded)"
    try:
        out = subprocess.check_output(["powershell","-NoProfile","-Command",ps], stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", timeout=10).strip().lower()
        return out in ("true","1")
    except Exception:
        return False

def eject_drive(letter: str) -> None:
    if not letter: return
    letter = letter.rstrip("\\/").upper()
    if not letter.endswith(":"): letter += ":"
    ps = f'(New-Object -comObject Shell.Application).NameSpace(17).ParseName("{letter}").InvokeVerb("Eject")'
    subprocess.run(["powershell","-NoProfile","-Command",ps], check=False)

def run_cmd(cmd: List[str], log_path: Path) -> int:
    ensure_dir(log_path.parent)
    with log_path.open("w", encoding="utf-8", errors="replace") as f:
        f.write("CMD: " + " ".join(cmd) + "\n\n")
        f.flush()
        p = subprocess.Popen(cmd, stdout=f, stderr=subprocess.STDOUT, text=True)
        return p.wait()

def ffprobe_json(path: Path) -> Dict:
    cmd = ["ffprobe","-v","error","-show_format","-show_streams","-print_format","json",str(path)]
    out = subprocess.check_output(cmd, text=True, encoding="utf-8", errors="replace")
    return json.loads(out)

def duration_seconds(probe: Dict) -> float:
    fmt = probe.get("format", {}) or {}
    try: return float(fmt.get("duration", 0.0))
    except Exception: return 0.0

def summarize_streams(probe: Dict) -> Tuple[int,int,int]:
    streams = probe.get("streams") or []
    a = sum(1 for s in streams if s.get("codec_type")=="audio")
    sub = sum(1 for s in streams if s.get("codec_type")=="subtitle")
    v = sum(1 for s in streams if s.get("codec_type")=="video")
    return v,a,sub

def prompt_real_cut_choice(folder_name: str, candidates: List[Dict]) -> Dict:
    import tkinter as tk
    from tkinter import ttk, messagebox
    root = tk.Tk()
    root.title("DiscMapper — Help identify real cut")
    root.geometry("980x520")
    top = ttk.Frame(root, padding=10); top.pack(fill="both", expand=True)
    ttk.Label(top, text=f"Multiple feature-length cuts detected in:\n{folder_name}\n\nSelect ONE cut to keep, or send everything to Review.", justify="left").pack(anchor="w", pady=(0,10))

    cols=("duration","size_gb","audio","subs","file")
    tree = ttk.Treeview(top, columns=cols, show="headings", height=14)
    for c,t,w,anch in [("duration","Duration (min)",110,"e"),("size_gb","Size (GB)",90,"e"),("audio","Audio tracks",110,"e"),("subs","Subtitle tracks",130,"e"),("file","Filename",480,"w")]:
        tree.heading(c, text=t); tree.column(c, width=w, anchor=anch)
    tree.pack(fill="both", expand=True)

    for c in candidates:
        tree.insert("", "end", values=(c["duration_min"], c["size_gb"], c["audio_streams"], c["subtitle_streams"], c["name"]), tags=(c["path"],))
    items = tree.get_children()
    if items: tree.selection_set(items[0])

    choice={"action":"review"}

    def selected_path():
        sel=tree.selection()
        if not sel: return None
        tags=tree.item(sel[0],"tags")
        return tags[0] if tags else None

    btns=ttk.Frame(top); btns.pack(fill="x", pady=(10,0))

    def keep_selected():
        p=selected_path()
        if not p:
            messagebox.showwarning("DiscMapper","Select a cut first.")
            return
        choice["action"]="keep_one"; choice["path"]=p; root.destroy()

    def keep_all():
        choice["action"]="review_keep_all"; root.destroy()

    def review():
        choice["action"]="review"; root.destroy()

    ttk.Button(btns, text="Keep SELECTED cut (recommended)", command=keep_selected).pack(side="left")
    ttk.Button(btns, text="Keep ALL (send folder to Review)", command=keep_all).pack(side="left", padx=8)
    ttk.Button(btns, text="Send to Review (decide later)", command=review).pack(side="right")

    root.mainloop()
    return choice

def pick_keeper_or_prompt(config: Dict, folder: Path, min_main_seconds: int) -> Dict:
    tol=int(config["finish"].get("dedupe_duration_tolerance_seconds",2))
    multi_cut=int(config["finish"].get("multi_cut_threshold_seconds",180))

    mkvs=sorted(folder.glob("*.mkv"))
    if not mkvs: return {"status":"review","reason":"no_mkv_files"}

    infos=[]
    for f in mkvs:
        try:
            probe=ffprobe_json(f)
            dur=duration_seconds(probe)
            v,a,sub=summarize_streams(probe)
        except Exception:
            dur=0.0; a=sub=v=0
        infos.append({
            "path": str(f),
            "name": f.name,
            "size_bytes": f.stat().st_size,
            "size_gb": round(f.stat().st_size/(1024**3),3),
            "duration_sec": dur,
            "duration_min": round(dur/60.0,2) if dur else 0.0,
            "audio_streams": a,
            "subtitle_streams": sub
        })

    candidates=[x for x in infos if x["duration_sec"]>=min_main_seconds]
    if not candidates: return {"status":"review","reason":f"no_candidate_over_{min_main_seconds//60}m"}

    candidates.sort(key=lambda x:(x["duration_sec"], x["size_bytes"]), reverse=True)

    clusters=[]
    for it in candidates:
        placed=False
        for cl in clusters:
            if abs(cl[0]["duration_sec"]-it["duration_sec"])<=tol:
                cl.append(it); placed=True; break
        if not placed: clusters.append([it])

    if len(clusters)>1:
        d0=clusters[0][0]["duration_sec"]; d1=clusters[1][0]["duration_sec"]
        if abs(d0-d1)>multi_cut:
            choice=prompt_real_cut_choice(folder.name, candidates)
            if choice["action"]=="review_keep_all":
                return {"status":"review","reason":"user_chose_keep_all_to_review","candidates":candidates}
            if choice["action"]=="review":
                return {"status":"review","reason":"user_sent_to_review","candidates":candidates}
            if choice["action"]=="keep_one":
                return {"status":"success","keeper_path":choice["path"],"candidates":candidates,"reason":"user_selected_cut"}
            return {"status":"review","reason":"no_user_choice","candidates":candidates}

    keeper=max(clusters[0], key=lambda x:x["size_bytes"])
    return {"status":"success","keeper_path":keeper["path"],"candidates":candidates,"reason":"auto_selected_best_candidate"}

def move_folder(folder: Path, target_root: Path) -> Path:
    ensure_dir(target_root)
    dest=target_root/folder.name
    if dest.exists(): dest=target_root/f"{folder.name}__{now_ts()}"
    return Path(shutil.move(str(folder), str(dest)))

def finish_success(config: Dict, job: Dict, folder: Path, keeper_path: str, candidates: List[Dict], reason: str) -> Dict:
    title=job["title"]; year=job.get("year"); imdb_id=job["imdb_id"]
    safe=sanitize_name(title)
    if year:
        folder_name=f"{safe} ({year}) {{imdb-{imdb_id}}}"
        file_name=f"{safe} ({year}) {{imdb-{imdb_id}}}.mkv"
    else:
        folder_name=f"{safe} {{imdb-{imdb_id}}}"
        file_name=f"{safe} {{imdb-{imdb_id}}}.mkv"

    dest_dir=Path(config["ready_root"])/folder_name
    ensure_dir(dest_dir)
    dest=dest_dir/file_name
    if dest.exists():
        stem,suf=dest.stem,dest.suffix; n=1
        while True:
            cand=dest_dir/f"{stem} ({n}){suf}"
            if not cand.exists(): dest=cand; break
            n+=1

    kp=Path(keeper_path)
    if config.get("move_mode","move").lower()=="copy":
        shutil.copy2(kp, dest)
    else:
        shutil.move(str(kp), str(dest))

    receipt={"status":"success","reason":reason,"keeper_dest":str(dest),"candidates":candidates,"completed_at":now_ts()}
    return receipt

def cmd_rip(args):
    config=load_config(args.config)
    qpath=Path(args.queue)
    if not qpath.exists(): raise FileNotFoundError(f"Queue not found: {qpath}")
    q=read_json_any(qpath)
    items=q.get("items",[])
    if not items:
        print("[DiscMapper v0.2] Queue is empty."); return

    makemkv=find_makemkvcon((config.get("makemkv",{}) or {}).get("makemkvcon_path",""))
    if not makemkv: raise RuntimeError("MakeMKV CLI not found. Install MakeMKV.")

    drive_index=(config.get("makemkv",{}) or {}).get("drive_index") or detect_drive_index(makemkv)
    minlength=int((config.get("makemkv",{}) or {}).get("minlength_seconds",2700))

    eject_cfg=config.get("eject",{}) or {}
    eject_enabled=bool(eject_cfg.get("enabled",True))
    drive_letter=eject_cfg.get("drive_letter") or ""
    if eject_enabled and not drive_letter:
        drive_letter=get_optical_drive_letter() or ""

    raw_root=Path(config["raw_root"]); ensure_dir(raw_root)
    review_root=Path(config["workbench_review"]); ensure_dir(review_root)
    unable_root=Path(config["workbench_unable"]); ensure_dir(unable_root)
    min_main=int(config.get("min_main_minutes",45)*60)

    print(f"[DiscMapper v0.2] MakeMKV: {makemkv}")
    print(f"[DiscMapper v0.2] Drive index: {drive_index}")
    print(f"[DiscMapper v0.2] Auto-eject: {'ON' if eject_enabled else 'OFF'} ({drive_letter or 'auto-detect failed'})")
    print(f"[DiscMapper v0.2] Raw root: {raw_root}")
    print(f"[DiscMapper v0.2] Ready root: {config['ready_root']}")
    print(f"[DiscMapper v0.2] Review: {review_root}")
    print(f"[DiscMapper v0.2] Unable: {unable_root}\n")

    for idx,it in enumerate(items, start=1):
        title=it["title"]; year=it.get("year"); imdb=it["imdb_id"].lower(); fmt=it.get("format","")
        safe=sanitize_name(title)
        folder_name=f"{safe} ({year}) {{imdb-{imdb}}}" if year else f"{safe} {{imdb-{imdb}}}"
        out_dir=raw_root/folder_name
        ensure_dir(out_dir)

        atomic_write_json(out_dir/".discmapper.job.json", {"title":title,"year":year,"imdb_id":imdb,"format":fmt,"queue_index":idx,"queue_total":len(items),"created_at":now_ts()})

        print(f"=== [{idx}/{len(items)}] NEXT DISC ===")
        print(f"Movie: {title} ({year or '????'}) [{imdb}]  Format: {fmt}")
        print("Waiting for disc... (Ctrl+C to stop)")
        while not is_media_loaded():
            time.sleep(1)

        log=out_dir/f"makemkv_{now_ts()}.log"
        cmd=[makemkv,"-r",f"--minlength={minlength}","mkv",f"disc:{drive_index}","all",str(out_dir)]
        print(f"[DiscMapper v0.2] Ripping... log: {log.name}")
        rc=run_cmd(cmd, log)

        if eject_enabled and drive_letter:
            eject_drive(drive_letter)

        if rc!=0:
            atomic_write_json(out_dir/".discmapper.receipt.json", {"status":"unable","reason":f"makemkv_error_rc_{rc}","completed_at":now_ts()})
            print(f"[DiscMapper v0.2] RIP ERROR (rc={rc}). Moving -> Unable_to_Read\n")
            move_folder(out_dir, unable_root)
            continue

        try:
            res=pick_keeper_or_prompt(config, out_dir, min_main)
        except Exception as e:
            res={"status":"review","reason":f"finish_exception: {e!r}"}

        if res.get("status")!="success":
            atomic_write_json(out_dir/".discmapper.receipt.json", {"status":"review","reason":res.get("reason"),"candidates":res.get("candidates",[]),"completed_at":now_ts()})
            print(f"[DiscMapper v0.2] REVIEW: {res.get('reason')}. Moving -> Movie Review\n")
            move_folder(out_dir, review_root)
            continue

        receipt=finish_success(config, {"title":title,"year":year,"imdb_id":imdb}, out_dir, res["keeper_path"], res.get("candidates",[]), res.get("reason",""))
        atomic_write_json(out_dir/".discmapper.receipt.json", receipt)
        print(f"[DiscMapper v0.2] DONE: {receipt['keeper_dest']}\n")

    print("[DiscMapper v0.2] Queue completed.")

def main():
    ap=argparse.ArgumentParser(prog="discmapper_v02")
    ap.add_argument("--config", default=None)
    sp=ap.add_subparsers(dest="cmd", required=True)

    p1=sp.add_parser("import-clz"); p1.add_argument("--clz", required=True); p1.add_argument("--out", default="clz_index.json"); p1.set_defaults(func=cmd_import_clz)
    p2=sp.add_parser("queue"); p2.add_argument("--index", default="clz_index.json"); p2.add_argument("--out", default="queue.json"); p2.set_defaults(func=cmd_queue)
    p3=sp.add_parser("rip"); p3.add_argument("--queue", default="queue.json"); p3.set_defaults(func=cmd_rip)

    args=ap.parse_args()
    args.func(args)

if __name__=="__main__":
    main()