# DiscMapper UNIFIED v0.2 Launcher
# Extract this folder to: C:\DiscMapper_UNIFIED_v02

$ErrorActionPreference = "Stop"

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here

function Ensure-Folders {
  $folders = @(
    "$here\Inputs",
    "$here\Data\Indexes",
    "$here\Data\Queues",
    "$here\Logs",
    "$here\Staging\Movies\1_Raw",
    "$here\Staging\Movies\2_Review",
    "$here\Staging\Movies\3_Ready",
    "$here\Staging\TV\1_Raw",
    "$here\Staging\TV\2_Review",
    "$here\Staging\TV\3_Ready",
    "$here\Staging\Unable_to_Read"
  )
  foreach ($f in $folders) {
    if (-not (Test-Path $f)) { New-Item -ItemType Directory -Force -Path $f | Out-Null }
  }
}

function Require-Python {
  $py = Get-Command python -ErrorAction SilentlyContinue
  if (-not $py) {
    Write-Host "ERROR: 'python' not found in PATH." -ForegroundColor Red
    Write-Host "Install Python 3.x from python.org and make sure 'python' is in PATH." -ForegroundColor Yellow
    Pause
    exit 1
  }
}

function Run-Unified([string]$subcommand) {
  Require-Python
  Ensure-Folders
  $app = Join-Path $here "App\discmapper_unified.py"
  & python $app $subcommand
  $rc = $LASTEXITCODE
  if ($rc -ne 0) {
    Write-Host "`nDiscMapper exited with code $rc" -ForegroundColor Yellow
  }
  "`n"
  Pause
}

while ($true) {
  Clear-Host
  Write-Host "==== DiscMapper UNIFIED v0.2 ====" -ForegroundColor Cyan
  Write-Host ""
  Write-Host "1) Refresh Index (Movies or TV)"
  Write-Host "2) Build Queue (Movies or TV)"
  Write-Host "3) Run Rip Queue (Movies or TV)"
  Write-Host "4) Exit"
  Write-Host ""
  $choice = Read-Host "Select"

  switch ($choice) {
    "1" { Run-Unified "refresh-index" }
    "2" { Run-Unified "queue-builder" }
    "3" { Run-Unified "run-rip" }
    "4" { break }
    default { Write-Host "Invalid choice. Press Enter." -ForegroundColor Yellow; Read-Host | Out-Null }
  }
}
